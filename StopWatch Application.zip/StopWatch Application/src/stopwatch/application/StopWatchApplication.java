
package stopwatch.application;

public class StopWatchApplication {

    public static void main(String[] args) {
        // TODO code application logic here
        Stopwatch stopwatch = new Stopwatch();
    }
    
}
